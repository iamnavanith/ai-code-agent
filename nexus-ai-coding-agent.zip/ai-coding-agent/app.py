"""
Nexus — an AI coding agent workspace.

A Flask app that provides:
  - a landing page
  - a workspace (chat + sidebar navigation)
  - a Skills system (reusable system-prompt snippets, enable/disable)
  - a Knowledge Base (upload docs, keyword-indexed, cited in chat answers)
  - Settings (theme, accent color, model choice)
  - live streaming chat against the Anthropic Messages API

Run:
    export ANTHROPIC_API_KEY=sk-ant-...
    pip install -r requirements.txt
    python app.py
Then open http://localhost:5000
"""
import os
import io
import json
import sqlite3
import time
import uuid
from datetime import datetime, timezone

import requests
from flask import (
    Flask, g, render_template, request, jsonify, Response,
    stream_with_context, send_from_directory
)

from knowledge import extract_text, chunk_text, KeywordIndex

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "instance", "nexus.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
AVAILABLE_MODELS = [
    {"id": "claude-sonnet-4-6", "label": "Claude Sonnet — balanced, fast"},
    {"id": "claude-opus-4-8", "label": "Claude Opus — most capable"},
    {"id": "claude-haiku-4-5-20251001", "label": "Claude Haiku — fastest"},
]

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024  # 25MB upload cap

# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS chats (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL DEFAULT 'New chat',
    pinned INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    chat_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS skills (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    prompt TEXT NOT NULL DEFAULT '',
    version TEXT NOT NULL DEFAULT '1.0.0',
    author TEXT NOT NULL DEFAULT 'You',
    tags TEXT NOT NULL DEFAULT '',
    enabled INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS knowledge_files (
    id TEXT PRIMARY KEY,
    filename TEXT NOT NULL,
    filetype TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    chunk_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS knowledge_chunks (
    id TEXT PRIMARY KEY,
    file_id TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    content TEXT NOT NULL,
    FOREIGN KEY (file_id) REFERENCES knowledge_files(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""

DEFAULT_SETTINGS = {
    "theme": "light",
    "accent": "blue",
    "model": "claude-sonnet-4-6",
    "knowledge_mode": "off",  # off | on  (answer using uploaded knowledge)
}


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    for k, v in DEFAULT_SETTINGS.items():
        conn.execute(
            "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v)
        )
    conn.commit()
    conn.close()


def now():
    return datetime.now(timezone.utc).isoformat()


# --------------------------------------------------------------------------
# Pages
# --------------------------------------------------------------------------

@app.route("/")
def landing():
    return render_template("landing.html")


@app.route("/offline")
def offline():
    return render_template("offline.html")


@app.route("/sw.js")
def service_worker():
    # Served from root (not /static/) so its default scope covers the whole
    # app — a service worker registered from /static/js/sw.js would only be
    # allowed to control /static/* by default.
    resp = send_from_directory(
        os.path.join(BASE_DIR, "static", "js"), "sw.js", mimetype="application/javascript"
    )
    resp.headers["Service-Worker-Allowed"] = "/"
    resp.headers["Cache-Control"] = "no-cache"
    return resp



@app.route("/workspace")
@app.route("/workspace/<view>")
def workspace(view="chat"):
    db = get_db()
    chats = db.execute(
        "SELECT * FROM chats ORDER BY pinned DESC, created_at DESC"
    ).fetchall()
    skills = db.execute("SELECT * FROM skills ORDER BY created_at DESC").fetchall()
    files = db.execute(
        "SELECT * FROM knowledge_files ORDER BY created_at DESC"
    ).fetchall()
    settings = {r["key"]: r["value"] for r in db.execute("SELECT * FROM settings")}
    active_chat_id = request.args.get("chat")
    active_chat = None
    messages = []
    if view == "chat":
        if active_chat_id:
            active_chat = db.execute(
                "SELECT * FROM chats WHERE id = ?", (active_chat_id,)
            ).fetchone()
            messages = db.execute(
                "SELECT * FROM messages WHERE chat_id = ? ORDER BY created_at ASC",
                (active_chat_id,),
            ).fetchall()
        elif chats:
            active_chat = chats[0]
            messages = db.execute(
                "SELECT * FROM messages WHERE chat_id = ? ORDER BY created_at ASC",
                (active_chat["id"],),
            ).fetchall()

    return render_template(
        "workspace.html",
        view=view,
        chats=chats,
        skills=skills,
        files=files,
        settings=settings,
        active_chat=active_chat,
        messages=messages,
        models=AVAILABLE_MODELS,
    )


# --------------------------------------------------------------------------
# Chats API
# --------------------------------------------------------------------------

@app.post("/api/chats")
def create_chat():
    db = get_db()
    chat_id = str(uuid.uuid4())
    db.execute(
        "INSERT INTO chats (id, title, created_at) VALUES (?, ?, ?)",
        (chat_id, "New chat", now()),
    )
    db.commit()
    return jsonify({"id": chat_id})


@app.delete("/api/chats/<chat_id>")
def delete_chat(chat_id):
    db = get_db()
    db.execute("DELETE FROM chats WHERE id = ?", (chat_id,))
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/chats/<chat_id>/pin")
def pin_chat(chat_id):
    db = get_db()
    row = db.execute("SELECT pinned FROM chats WHERE id = ?", (chat_id,)).fetchone()
    if not row:
        return jsonify({"error": "not found"}), 404
    db.execute(
        "UPDATE chats SET pinned = ? WHERE id = ?", (0 if row["pinned"] else 1, chat_id)
    )
    db.commit()
    return jsonify({"ok": True})


@app.get("/api/chats/search")
def search_chats():
    q = request.args.get("q", "").strip()
    db = get_db()
    if not q:
        return jsonify([])
    rows = db.execute(
        """
        SELECT DISTINCT c.id, c.title FROM chats c
        JOIN messages m ON m.chat_id = c.id
        WHERE c.title LIKE ? OR m.content LIKE ?
        ORDER BY c.created_at DESC LIMIT 20
        """,
        (f"%{q}%", f"%{q}%"),
    ).fetchall()
    return jsonify([dict(r) for r in rows])


# --------------------------------------------------------------------------
# Chat streaming (Server-Sent Events)
# --------------------------------------------------------------------------

def build_system_prompt(db):
    parts = [
        "You are Nexus, a precise and pragmatic AI coding assistant embedded "
        "in a developer workspace. Prefer concrete, runnable code over vague "
        "advice. Use markdown code fences with language tags. Keep explanations "
        "focused unless the user asks for depth."
    ]
    enabled_skills = db.execute(
        "SELECT * FROM skills WHERE enabled = 1"
    ).fetchall()
    if enabled_skills:
        parts.append("\n\nActive skills for this conversation:")
        for s in enabled_skills:
            parts.append(f"\n### Skill: {s['name']}\n{s['prompt']}")
    return "\n".join(parts)


def retrieve_knowledge_context(db, query, k=4):
    files = db.execute("SELECT id FROM knowledge_files").fetchall()
    if not files:
        return "", []
    chunks = db.execute(
        "SELECT kc.content, kc.chunk_index, kf.filename, kf.id as file_id "
        "FROM knowledge_chunks kc JOIN knowledge_files kf ON kf.id = kc.file_id"
    ).fetchall()
    index = KeywordIndex()
    for c in chunks:
        index.add(f"{c['file_id']}:{c['chunk_index']}", c["content"])
    top = index.search(query, k=k)
    if not top:
        return "", []
    used_files = set()
    context_parts = []
    citations = []
    lookup = {f"{c['file_id']}:{c['chunk_index']}": c for c in chunks}
    for key, score in top:
        c = lookup[key]
        used_files.add(c["filename"])
        context_parts.append(f"[Source: {c['filename']}]\n{c['content']}")
        citations.append(c["filename"])
    context = "\n\n---\n\n".join(context_parts)
    return context, sorted(used_files)


@app.post("/api/chat/stream")
def chat_stream():
    db = get_db()
    data = request.get_json(force=True)
    chat_id = data.get("chat_id")
    user_message = data.get("message", "").strip()
    model = data.get("model") or DEFAULT_SETTINGS["model"]
    knowledge_mode = data.get("knowledge_mode", "off")

    if not chat_id:
        chat_id = str(uuid.uuid4())
        title = (user_message[:48] + "…") if len(user_message) > 48 else user_message
        db.execute(
            "INSERT INTO chats (id, title, created_at) VALUES (?, ?, ?)",
            (chat_id, title or "New chat", now()),
        )
        db.commit()

    row = db.execute("SELECT COUNT(*) c FROM messages WHERE chat_id=?", (chat_id,)).fetchone()
    if row["c"] == 0:
        title = (user_message[:48] + "…") if len(user_message) > 48 else user_message
        db.execute("UPDATE chats SET title=? WHERE id=?", (title or "New chat", chat_id))

    db.execute(
        "INSERT INTO messages (id, chat_id, role, content, created_at) VALUES (?,?,?,?,?)",
        (str(uuid.uuid4()), chat_id, "user", user_message, now()),
    )
    db.commit()

    history = db.execute(
        "SELECT role, content FROM messages WHERE chat_id=? ORDER BY created_at ASC",
        (chat_id,),
    ).fetchall()

    system_prompt = build_system_prompt(db)
    citations = []
    if knowledge_mode == "on":
        context, citations = retrieve_knowledge_context(db, user_message)
        if context:
            system_prompt += (
                "\n\nAnswer using the following knowledge base excerpts when "
                "relevant. Cite the source filename in your answer. If the "
                "excerpts don't cover the question, say so plainly.\n\n"
                f"{context}"
            )

    api_messages = [{"role": r["role"], "content": r["content"]} for r in history]

    api_key = os.environ.get("ANTHROPIC_API_KEY")

    def save_assistant_message(text):
        # The generator runs after the request/app context that owns g.db has
        # been torn down, so it needs its own short-lived connection rather
        # than reusing get_db().
        conn = sqlite3.connect(DB_PATH)
        try:
            conn.execute(
                "INSERT INTO messages (id, chat_id, role, content, created_at) VALUES (?,?,?,?,?)",
                (str(uuid.uuid4()), chat_id, "assistant", text, now()),
            )
            conn.commit()
        finally:
            conn.close()

    def generate():
        yield f"event: meta\ndata: {json.dumps({'chat_id': chat_id, 'citations': citations})}\n\n"

        if not api_key:
            msg = (
                "No ANTHROPIC_API_KEY is set on the server, so I can't reach the "
                "model. Set the environment variable and restart the app to enable "
                "live responses."
            )
            save_assistant_message(msg)
            yield f"event: delta\ndata: {json.dumps({'text': msg})}\n\n"
            yield "event: done\ndata: {}\n\n"
            return

        payload = {
            "model": model,
            "max_tokens": 4096,
            "system": system_prompt,
            "messages": api_messages,
            "stream": True,
        }
        headers = {
            "x-api-key": api_key,
            "anthropic-version": ANTHROPIC_VERSION,
            "content-type": "application/json",
        }

        full_text = []
        try:
            with requests.post(
                ANTHROPIC_API_URL, headers=headers, json=payload, stream=True, timeout=120
            ) as resp:
                if resp.status_code != 200:
                    err = resp.text[:500]
                    yield f"event: error\ndata: {json.dumps({'message': err})}\n\n"
                    return
                for line in resp.iter_lines(decode_unicode=True):
                    if not line or not line.startswith("data:"):
                        continue
                    raw = line[len("data:"):].strip()
                    if raw == "[DONE]":
                        break
                    try:
                        evt = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    if evt.get("type") == "content_block_delta":
                        delta = evt.get("delta", {})
                        text = delta.get("text", "")
                        if text:
                            full_text.append(text)
                            yield f"event: delta\ndata: {json.dumps({'text': text})}\n\n"
                    elif evt.get("type") == "message_stop":
                        break
        except requests.RequestException as e:
            yield f"event: error\ndata: {json.dumps({'message': str(e)})}\n\n"
            return

        final_text = "".join(full_text)
        if final_text:
            save_assistant_message(final_text)
        yield "event: done\ndata: {}\n\n"

    return Response(stream_with_context(generate()), mimetype="text/event-stream")


# --------------------------------------------------------------------------
# Skills API
# --------------------------------------------------------------------------

@app.post("/api/skills")
def create_skill():
    data = request.get_json(force=True)
    db = get_db()
    skill_id = str(uuid.uuid4())
    db.execute(
        """INSERT INTO skills (id, name, description, prompt, version, author, tags, enabled, created_at)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (
            skill_id,
            data.get("name", "Untitled skill"),
            data.get("description", ""),
            data.get("prompt", ""),
            data.get("version", "1.0.0"),
            data.get("author", "You"),
            data.get("tags", ""),
            1 if data.get("enabled") else 0,
            now(),
        ),
    )
    db.commit()
    return jsonify({"id": skill_id})


@app.put("/api/skills/<skill_id>")
def update_skill(skill_id):
    data = request.get_json(force=True)
    db = get_db()
    db.execute(
        """UPDATE skills SET name=?, description=?, prompt=?, version=?, author=?, tags=?
           WHERE id=?""",
        (
            data.get("name", "Untitled skill"),
            data.get("description", ""),
            data.get("prompt", ""),
            data.get("version", "1.0.0"),
            data.get("author", "You"),
            data.get("tags", ""),
            skill_id,
        ),
    )
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/skills/<skill_id>/toggle")
def toggle_skill(skill_id):
    db = get_db()
    row = db.execute("SELECT enabled FROM skills WHERE id=?", (skill_id,)).fetchone()
    if not row:
        return jsonify({"error": "not found"}), 404
    db.execute(
        "UPDATE skills SET enabled=? WHERE id=?", (0 if row["enabled"] else 1, skill_id)
    )
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/skills/<skill_id>")
def delete_skill(skill_id):
    db = get_db()
    db.execute("DELETE FROM skills WHERE id=?", (skill_id,))
    db.commit()
    return jsonify({"ok": True})


@app.get("/api/skills/export")
def export_skills():
    db = get_db()
    rows = db.execute("SELECT * FROM skills").fetchall()
    payload = [dict(r) for r in rows]
    return Response(
        json.dumps(payload, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": "attachment; filename=nexus-skills.json"},
    )


@app.post("/api/skills/import")
def import_skills():
    payload = request.get_json(force=True)
    db = get_db()
    imported = 0
    for s in payload if isinstance(payload, list) else []:
        db.execute(
            """INSERT INTO skills (id, name, description, prompt, version, author, tags, enabled, created_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (
                str(uuid.uuid4()),
                s.get("name", "Imported skill"),
                s.get("description", ""),
                s.get("prompt", ""),
                s.get("version", "1.0.0"),
                s.get("author", "Imported"),
                s.get("tags", ""),
                0,
                now(),
            ),
        )
        imported += 1
    db.commit()
    return jsonify({"imported": imported})


# --------------------------------------------------------------------------
# Knowledge base API
# --------------------------------------------------------------------------

@app.post("/api/knowledge/upload")
def upload_knowledge():
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    f = request.files["file"]
    filename = f.filename
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    file_id = str(uuid.uuid4())
    saved_path = os.path.join(UPLOAD_DIR, f"{file_id}_{filename}")
    f.save(saved_path)
    size_bytes = os.path.getsize(saved_path)

    try:
        text = extract_text(saved_path, ext)
    except Exception as e:
        return jsonify({"error": f"could not read file: {e}"}), 400

    chunks = chunk_text(text)
    db = get_db()
    db.execute(
        """INSERT INTO knowledge_files (id, filename, filetype, size_bytes, chunk_count, created_at)
           VALUES (?,?,?,?,?,?)""",
        (file_id, filename, ext, size_bytes, len(chunks), now()),
    )
    for i, c in enumerate(chunks):
        db.execute(
            "INSERT INTO knowledge_chunks (id, file_id, chunk_index, content) VALUES (?,?,?,?)",
            (str(uuid.uuid4()), file_id, i, c),
        )
    db.commit()
    return jsonify({"id": file_id, "filename": filename, "chunks": len(chunks)})


@app.delete("/api/knowledge/<file_id>")
def delete_knowledge(file_id):
    db = get_db()
    row = db.execute("SELECT filename FROM knowledge_files WHERE id=?", (file_id,)).fetchone()
    db.execute("DELETE FROM knowledge_files WHERE id=?", (file_id,))
    db.commit()
    if row:
        for fn in os.listdir(UPLOAD_DIR):
            if fn.startswith(file_id):
                try:
                    os.remove(os.path.join(UPLOAD_DIR, fn))
                except OSError:
                    pass
    return jsonify({"ok": True})


@app.get("/api/knowledge/search")
def search_knowledge():
    q = request.args.get("q", "").strip()
    db = get_db()
    if not q:
        return jsonify([])
    context, files = retrieve_knowledge_context(db, q)
    return jsonify({"context": context, "files": files})


# --------------------------------------------------------------------------
# Settings API
# --------------------------------------------------------------------------

@app.post("/api/settings")
def update_settings():
    data = request.get_json(force=True)
    db = get_db()
    for k, v in data.items():
        db.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (k, str(v)),
        )
    db.commit()
    return jsonify({"ok": True})


@app.get("/api/settings")
def get_settings():
    db = get_db()
    return jsonify({r["key"]: r["value"] for r in db.execute("SELECT * FROM settings")})


@app.get("/api/status")
def api_status():
    return jsonify({"api_key_configured": bool(os.environ.get("ANTHROPIC_API_KEY"))})


if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    # use_reloader=False: the reloader's file-watcher would otherwise trigger
    # on every SQLite write to instance/nexus.db and restart the process.
    app.run(host="0.0.0.0", port=port, debug=True, use_reloader=False)
else:
    init_db()
