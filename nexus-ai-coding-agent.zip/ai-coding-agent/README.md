# Nexus — AI Coding Agent (Flask)

A working AI coding-assistant workspace: landing page, streaming chat, a
reusable **Skills** system, a **Knowledge Base** with citation-backed
retrieval, and light/dark theming with an accent picker — built to the
palette and layout in the brief.

## Quick start

```bash
cd ai-coding-agent
pip install -r requirements.txt

export ANTHROPIC_API_KEY=sk-ant-...     # get one at console.anthropic.com
python app.py
```

Open **http://localhost:5000**.

## Installing it on your phone

The app is now an installable PWA — icon, theme color, and an offline
fallback screen are wired up. A PWA still needs a server to talk to
though, so pick one path:

**Fastest — same Wi-Fi as your computer**
1. On your computer: `python app.py` (leave `ANTHROPIC_API_KEY` set).
2. Find your computer's local IP — macOS/Linux: `ipconfig getifaddr en0` or
   `hostname -I`; Windows: `ipconfig` → IPv4 Address.
3. On your phone (same Wi-Fi), open `http://<that-ip>:5000` in Safari (iOS)
   or Chrome (Android).
4. iOS: Share → **Add to Home Screen**. Android/Chrome: menu (⋮) →
   **Add to Home screen** / **Install app**.
5. You'll get a Nexus icon that opens full-screen, no browser chrome.

This only works while your computer is on and both devices share Wi-Fi.

**For access from anywhere — deploy it**
Push this folder to a small host and point your phone at the public URL
instead of a local IP, then install the same way. Free/cheap options that
work well for a small Flask + SQLite app: **Render**, **Railway**, **Fly.io**,
or **PythonAnywhere**. Wherever you deploy, set `ANTHROPIC_API_KEY` as an
environment variable in that platform's dashboard — never commit it to
the repo.

Without an API key the app still runs — chat will tell you a key isn't
configured instead of failing silently. Everything else (skills, knowledge
base, settings) works with no key at all.

## What's actually implemented

- **Landing page** — hero, gradient background, the five primary actions
  from the brief (GitHub import is stubbed — see below).
- **Chat** — streams token-by-token from the Claude API over SSE, renders
  markdown + syntax-highlighted code, keeps per-chat history in SQLite,
  supports pin/delete/search.
- **Skills** — create/edit/enable/disable/delete/import/export. Enabled
  skills' prompts are injected into the system prompt for every chat.
- **Knowledge Base** — upload PDF/DOCX/TXT/MD/CSV/ZIP, text is extracted
  and chunked, a small built-in BM25-style search retrieves relevant
  chunks and cites the source filename in answers when "Knowledge mode"
  is on.
- **Settings** — light/dark theme, accent color, default model, all
  persisted server-side.

## What's scaffolded but not wired up

The brief describes a full enterprise SaaS (OAuth/SSO, 2FA, billing,
admin console, RBAC, live multi-user collaboration, Docker/CI-CD infra,
a full in-browser terminal and code runner, a plugin marketplace). That's
a multi-quarter engineering effort for a real team, not something to fake
convincingly in one build. Rather than stub all of it out with fake
buttons, this build:

- Implements the core loop (chat + skills + knowledge + settings) for real.
- Leaves `Projects`, `Files`, `Extensions`, `Agents`, and `History` as
  clearly-labeled "coming soon" pages in the sidebar, so the navigation
  matches the spec and each page is a clean place to extend from.
- Stubs "Import from GitHub" with an explanatory message instead of a
  fake success state.

Natural next slices, in rough priority order: real auth (Flask-Login +
OAuth), a project/file tree backed by an actual uploaded folder or git
clone, an "Agents" layer that swaps system prompts + tool access per
persona, and a sandboxed code-execution tool for the terminal panel.

## Project layout

```
app.py            Flask app: routes, SSE chat streaming, skills & knowledge APIs
knowledge.py       Text extraction (pdf/docx/txt) + lightweight BM25 search
templates/          landing.html, workspace.html (chat/skills/knowledge/settings views)
static/css/         design tokens + component styles (palette from the brief)
static/js/          theme persistence, streaming chat client, skills/KB UI logic
instance/nexus.db   SQLite database (created on first run)
uploads/            raw uploaded knowledge files
```

## Notes

- Storage is SQLite — fine for a single user/demo, swap for Postgres
  before multi-user use.
- The dev server (`app.run`) is not for production; put it behind
  gunicorn/uwsgi + a reverse proxy for real deployment.
- `ANTHROPIC_API_KEY` is read from the environment only — never hardcode it.
