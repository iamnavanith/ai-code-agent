"""
Lightweight, dependency-minimal knowledge-base utilities:
  - extract_text(): pull plain text out of pdf / docx / txt / md / csv
  - chunk_text(): split into overlapping chunks for retrieval
  - KeywordIndex: a small TF-IDF-like scorer (no numpy/sklearn required)
    good enough for a self-hosted knowledge base of a few hundred chunks.
"""
import math
import re
from collections import Counter, defaultdict


def extract_text(path: str, ext: str) -> str:
    ext = ext.lower()
    if ext in ("txt", "md", "markdown", "csv", "json"):
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    if ext == "pdf":
        from pypdf import PdfReader
        reader = PdfReader(path)
        return "\n\n".join((page.extract_text() or "") for page in reader.pages)
    if ext == "docx":
        import docx
        doc = docx.Document(path)
        return "\n".join(p.text for p in doc.paragraphs)
    if ext == "zip":
        return _extract_zip_summary(path)
    # source code / unknown text-ish files: best-effort read
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return ""


def _extract_zip_summary(path: str) -> str:
    import zipfile
    out = []
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if name.endswith("/"):
                continue
            out.append(f"# {name}")
            if name.rsplit(".", 1)[-1].lower() in (
                "py", "js", "ts", "tsx", "jsx", "md", "txt", "json", "html", "css", "yml", "yaml"
            ):
                try:
                    with z.open(name) as f:
                        content = f.read(20000).decode("utf-8", errors="ignore")
                        out.append(content)
                except Exception:
                    pass
    return "\n\n".join(out)


def chunk_text(text: str, chunk_size: int = 900, overlap: int = 150):
    text = re.sub(r"\r\n?", "\n", text).strip()
    if not text:
        return []
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + chunk_size, n)
        # try to break on a paragraph/sentence boundary near the end
        slice_ = text[start:end]
        if end < n:
            boundary = max(slice_.rfind("\n\n"), slice_.rfind(". "))
            if boundary > chunk_size * 0.4:
                end = start + boundary + 1
                slice_ = text[start:end]
        chunk = slice_.strip()
        if chunk:
            chunks.append(chunk)
        if end >= n:
            break
        start = max(end - overlap, start + 1)
    return chunks


_TOKEN_RE = re.compile(r"[a-zA-Z0-9_]+")


def _tokenize(s: str):
    return [t.lower() for t in _TOKEN_RE.findall(s)]


class KeywordIndex:
    """A minimal BM25-ish scorer over an in-memory set of documents."""

    def __init__(self):
        self.docs = {}  # id -> tokens
        self.raw = {}  # id -> original text

    def add(self, doc_id, text):
        self.docs[doc_id] = _tokenize(text)
        self.raw[doc_id] = text

    def search(self, query, k=4):
        if not self.docs:
            return []
        q_tokens = _tokenize(query)
        if not q_tokens:
            return []

        n_docs = len(self.docs)
        df = defaultdict(int)
        for tokens in self.docs.values():
            for term in set(tokens):
                df[term] += 1

        avg_len = sum(len(t) for t in self.docs.values()) / max(n_docs, 1)
        k1, b = 1.5, 0.75

        scores = []
        for doc_id, tokens in self.docs.items():
            if not tokens:
                continue
            tf = Counter(tokens)
            score = 0.0
            for term in q_tokens:
                if term not in tf:
                    continue
                idf = math.log(1 + (n_docs - df[term] + 0.5) / (df[term] + 0.5))
                freq = tf[term]
                denom = freq + k1 * (1 - b + b * len(tokens) / max(avg_len, 1))
                score += idf * (freq * (k1 + 1)) / max(denom, 1e-9)
            if score > 0:
                scores.append((doc_id, score))

        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:k]
