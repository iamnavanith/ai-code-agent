// ---------- markdown rendering ----------
function decodeHtmlEntities(str) {
  const ta = document.createElement('textarea');
  ta.innerHTML = str;
  return ta.value;
}
function renderMarkdown(el) {
  const raw = decodeHtmlEntities(el.getAttribute('data-raw') || '');
  if (window.marked) {
    marked.setOptions({
      highlight: function (code, lang) {
        if (window.hljs && lang && hljs.getLanguage(lang)) {
          try { return hljs.highlight(code, { language: lang }).value; } catch (e) {}
        }
        return code;
      },
    });
    el.innerHTML = marked.parse(raw);
    el.querySelectorAll('pre code').forEach((block) => {
      if (window.hljs) hljs.highlightElement(block);
    });
  } else {
    el.textContent = raw;
  }
}
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.rendered-md').forEach(renderMarkdown);
  scrollChatToBottom();
  const ta = document.getElementById('composer-input');
  if (ta) {
    ta.addEventListener('input', () => {
      ta.style.height = 'auto';
      ta.style.height = Math.min(ta.scrollHeight, 160) + 'px';
    });
    ta.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });
  }
  const dz = document.getElementById('dropzone');
  if (dz) {
    ['dragenter', 'dragover'].forEach((evt) =>
      dz.addEventListener(evt, (e) => { e.preventDefault(); dz.classList.add('drag'); })
    );
    ['dragleave', 'drop'].forEach((evt) =>
      dz.addEventListener(evt, (e) => { e.preventDefault(); dz.classList.remove('drag'); })
    );
    dz.addEventListener('drop', (e) => {
      if (e.dataTransfer.files.length) uploadKnowledgeFiles(e.dataTransfer.files);
    });
  }
  fetch('/api/status').then(r => r.json()).then(d => {
    const pill = document.getElementById('api-status-pill');
    if (pill) {
      pill.textContent = d.api_key_configured ? 'Connected' : 'Not configured';
      pill.classList.toggle('on', d.api_key_configured);
    }
  }).catch(() => {});
});

function scrollChatToBottom() {
  const scroller = document.getElementById('chat-scroll');
  if (scroller) scroller.scrollTop = scroller.scrollHeight;
}

// ---------- chat ----------
function createChat() {
  fetch('/api/chats', { method: 'POST' })
    .then((r) => r.json())
    .then((d) => (window.location.href = '/workspace?chat=' + d.id));
}
function deleteChat(id) {
  if (!confirm('Delete this chat?')) return;
  fetch('/api/chats/' + id, { method: 'DELETE' }).then(() => {
    if (window.NEXUS_STATE.activeChatId === id) window.location.href = '/workspace';
    else window.location.reload();
  });
}
function pinChat(id) {
  fetch('/api/chats/' + id + '/pin', { method: 'POST' }).then(() => window.location.reload());
}
function toggleKnowledgeMode() {
  const next = window.NEXUS_STATE.knowledgeMode === 'on' ? 'off' : 'on';
  window.NEXUS_STATE.knowledgeMode = next;
  saveSetting('knowledge_mode', next);
  window.location.reload();
}

function appendMessage(role, text) {
  const stream = document.getElementById('msg-stream');
  const empty = stream.querySelector('.empty-state');
  if (empty) empty.remove();
  const wrap = document.createElement('div');
  wrap.className = 'msg ' + role;
  wrap.innerHTML = `<div class="avatar">${role === 'user' ? 'You' : 'N'}</div><div class="bubble"></div>`;
  stream.appendChild(wrap);
  scrollChatToBottom();
  return wrap.querySelector('.bubble');
}

let sending = false;

function sendMessage() {
  if (sending) return;
  const input = document.getElementById('composer-input');
  const text = input.value.trim();
  if (!text) return;
  sending = true;
  document.getElementById('send-btn').disabled = true;

  appendMessage('user', text).textContent = text;
  input.value = '';
  input.style.height = 'auto';

  const bubble = appendMessage('assistant', '');
  bubble.innerHTML = '<span class="typing-dots"><span></span><span></span><span></span></span>';

  fetch('/api/chat/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: window.NEXUS_STATE.activeChatId,
      message: text,
      model: window.NEXUS_STATE.model,
      knowledge_mode: window.NEXUS_STATE.knowledgeMode,
    }),
  }).then((resp) => {
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    let full = '';
    let firstDelta = true;

    function pump() {
      return reader.read().then(({ done, value }) => {
        if (done) {
          finish();
          return;
        }
        buf += decoder.decode(value, { stream: true });
        const events = buf.split('\n\n');
        buf = events.pop();
        for (const evt of events) handleEvent(evt);
        return pump();
      });
    }

    function handleEvent(raw) {
      const lines = raw.split('\n');
      let eventName = 'message';
      let data = '';
      for (const line of lines) {
        if (line.startsWith('event:')) eventName = line.slice(6).trim();
        else if (line.startsWith('data:')) data += line.slice(5).trim();
      }
      if (!data) return;
      let parsed;
      try { parsed = JSON.parse(data); } catch (e) { return; }

      if (eventName === 'meta') {
        if (!window.NEXUS_STATE.activeChatId && parsed.chat_id) {
          window.NEXUS_STATE.activeChatId = parsed.chat_id;
          window.history.replaceState({}, '', '/workspace?chat=' + parsed.chat_id);
        }
        window.__lastCitations = parsed.citations || [];
      } else if (eventName === 'delta') {
        if (firstDelta) { bubble.innerHTML = ''; firstDelta = false; }
        full += parsed.text;
        bubble.textContent = full;
        scrollChatToBottom();
      } else if (eventName === 'error') {
        bubble.innerHTML = '<span style="color:#E15B5B;">⚠ ' + (parsed.message || 'Something went wrong.') + '</span>';
      }
    }

    function finish() {
      bubble.setAttribute('data-raw', full.replace(/&/g, '&amp;').replace(/</g, '&lt;'));
      renderMarkdown(bubble);
      if (window.__lastCitations && window.__lastCitations.length) {
        const cite = document.createElement('div');
        cite.className = 'citations';
        cite.innerHTML = window.__lastCitations
          .map((f) => `<span class="pill">📄 ${f}</span>`)
          .join('');
        bubble.appendChild(cite);
      }
      sending = false;
      document.getElementById('send-btn').disabled = false;
      // refresh sidebar chat titles occasionally
      const list = document.getElementById('chat-list');
      if (list && !window.NEXUS_STATE.titleSynced) {
        window.NEXUS_STATE.titleSynced = true;
      }
    }

    return pump();
  }).catch((err) => {
    bubble.innerHTML = '<span style="color:#E15B5B;">⚠ Connection error: ' + err + '</span>';
    sending = false;
    document.getElementById('send-btn').disabled = false;
  });
}

// ---------- skills ----------
function openSkillModal(skill) {
  document.getElementById('skill-modal').style.display = 'flex';
  document.getElementById('skill-modal-title').textContent = skill ? 'Edit skill' : 'New skill';
  document.getElementById('skill-id').value = skill ? skill.id : '';
  document.getElementById('skill-name').value = skill ? skill.name : '';
  document.getElementById('skill-description').value = skill ? skill.description : '';
  document.getElementById('skill-prompt').value = skill ? skill.prompt : '';
  document.getElementById('skill-version').value = skill ? skill.version : '1.0.0';
  document.getElementById('skill-author').value = skill ? skill.author : 'You';
  document.getElementById('skill-tags').value = skill ? skill.tags : '';
}
function closeSkillModal() {
  document.getElementById('skill-modal').style.display = 'none';
}
function saveSkill() {
  const id = document.getElementById('skill-id').value;
  const payload = {
    name: document.getElementById('skill-name').value || 'Untitled skill',
    description: document.getElementById('skill-description').value,
    prompt: document.getElementById('skill-prompt').value,
    version: document.getElementById('skill-version').value || '1.0.0',
    author: document.getElementById('skill-author').value || 'You',
    tags: document.getElementById('skill-tags').value,
  };
  const req = id
    ? fetch('/api/skills/' + id, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    : fetch('/api/skills', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
  req.then(() => window.location.reload());
}
function toggleSkill(id) {
  fetch('/api/skills/' + id + '/toggle', { method: 'POST' });
}
function deleteSkill(id) {
  if (!confirm('Delete this skill?')) return;
  fetch('/api/skills/' + id, { method: 'DELETE' }).then(() => window.location.reload());
}
function importSkills(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      fetch('/api/skills/import', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
        .then(() => window.location.reload());
    } catch (e) {
      alert('Invalid skills file.');
    }
  };
  reader.readAsText(file);
}

// ---------- knowledge base ----------
function uploadKnowledgeFiles(fileList) {
  const files = Array.from(fileList);
  let remaining = files.length;
  files.forEach((file) => {
    const fd = new FormData();
    fd.append('file', file);
    fetch('/api/knowledge/upload', { method: 'POST', body: fd })
      .then((r) => r.json())
      .then(() => {
        remaining -= 1;
        if (remaining === 0) window.location.reload();
      })
      .catch(() => {
        remaining -= 1;
        if (remaining === 0) window.location.reload();
      });
  });
}
function deleteKnowledge(id) {
  if (!confirm('Remove this file from the knowledge base?')) return;
  fetch('/api/knowledge/' + id, { method: 'DELETE' }).then(() => window.location.reload());
}
