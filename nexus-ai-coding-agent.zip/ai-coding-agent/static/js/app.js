// Shared across all pages: theme + accent persistence.
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  try { localStorage.setItem('nexus-theme', theme); } catch (e) {}
}
function applyAccent(accent) {
  document.documentElement.setAttribute('data-accent', accent);
  try { localStorage.setItem('nexus-accent', accent); } catch (e) {}
}
function setTheme(theme) {
  applyTheme(theme);
  document.querySelectorAll('.theme-opt').forEach(el => el.classList.remove('active'));
  const target = document.querySelector(`.theme-opt[title="${theme === 'light' ? 'Light' : 'Dark'}"]`);
  if (target) target.classList.add('active');
  saveSetting('theme', theme);
}
function setAccent(accent) {
  applyAccent(accent);
  document.querySelectorAll('.accent-opt').forEach(el => el.classList.remove('active'));
  const target = document.querySelector(`.accent-opt[data-c="${accent}"]`);
  if (target) target.classList.add('active');
  saveSetting('accent', accent);
}
function saveSetting(key, value) {
  fetch('/api/settings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ [key]: value }),
  }).catch(() => {});
}
